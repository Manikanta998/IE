package com.sn.beans;

public interface StudentMantService {
    public String studentRegister(Student student);

}
