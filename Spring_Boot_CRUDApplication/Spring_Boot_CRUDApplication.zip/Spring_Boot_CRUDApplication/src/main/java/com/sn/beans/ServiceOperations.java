package com.sn.beans;

public interface ServiceOperations {
}
