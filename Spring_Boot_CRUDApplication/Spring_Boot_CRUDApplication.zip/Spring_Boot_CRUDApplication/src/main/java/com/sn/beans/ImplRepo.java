package com.sn.beans;

import org.springframework.data.repository.CrudRepository;

public interface ImplRepo extends CrudRepository<Student,Integer> {
}
